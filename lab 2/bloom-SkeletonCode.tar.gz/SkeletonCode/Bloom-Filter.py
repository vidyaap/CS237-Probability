'''
Bloom Filter Class 
for Bloom Filter Lab
CS237, Sharon Goldberg
'''
from bloomFilterHash import bloomFilterHash 
import numpy.random as rnd

class BloomFilter(object):
    #Class Variables
    numBits = 0
    bitArray = [0]
    numHashFunctions = 0
    
    '''Insert function, pass it a key and insert into bloom filter'''
    def insert(self, key):
    
    '''Lookup function, pass it a key and return true or false'''
    def lookup(self, key):


    def __init__(self, numBits, numHashFunctions):
	self.numBits = numBits
	self.bitArray = [0] * numBits
	self.hash = bloomFilterHash(numBits, numHashFunctions)
