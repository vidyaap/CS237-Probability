'''
CS237 Lab 5
Sharon Goldberg
'''
import numpy as np
import math
from matplotlib import pyplot as plt

class SecondMomentEstimator(object):
    counterArray = [0]
    m = 0
    actualDataArray = [0]
    #Generate a random Packet
    def packetGenerator(self):
        return np.random.randint(math.pow(2,14)) 
    #Generates hash functions to use
    def generateHashFunction(self):
        a = np.random.random_integers(0, 100000, 4)
        return (a[0], a[1], a[2], a[3])
    #Use this for a 4-wise independent hash
    def hash_4i(self, key):
        (a,b,c,d) = self.generateHashFunction()
        val = a * math.pow(key, 3) + b * math.pow(key, 2) + c * key + d
        ret = int(val % len(self.counterArray))
        return ret
    
    def dataStream(self, numPackets):
       
        
    def actualF2(self):
      
   
    def estimateF2(self):
       
    
    def __init__(self, m):
       